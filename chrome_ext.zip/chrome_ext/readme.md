#Features
1. Open recently closed tab
2. save url
3. voice operation
4. AI assistant - Core
5. Get definition of word just by highlighting it 